  </div> <!-- End container -->
  <footer class="bg-light text-center py-3 mt-5">
    <small>&copy; <?= date('Y') ?> JobBoard Platform</small>
  </footer>
</body>
</html>
