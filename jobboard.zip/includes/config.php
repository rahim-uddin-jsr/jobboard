<?php
define('BASE_URL', 'http://localhost/jobboard/');


define('DB_HOST', 'localhost');
define('DB_NAME', 'jobboard');
define('DB_USER', 'root');
define('DB_PASS', '');
